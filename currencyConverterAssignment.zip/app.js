class Currency {
  constructor(code, name, exchangeRate) {
    this.code = code;
    this.name = name;
    this.exchangeRate = exchangeRate;
  }
}

class CurrencyManager {
  constructor() {
    this.currencies = [];
  }

  addCurrency(currency) {
    this.currencies.push(currency);
  }

  getCurrencies() {
    return this.currencies;
  }

  async updateExchangeRates(apiKey) {
    try {
      const response = await fetch(`https://open.er-api.com/v6/latest/USD?apikey=${apiKey}`);
      const data = await response.json();

      if (data.result === 'success') {
        const rates = data.rates;
        this.currencies = []; // Clear existing currencies

        // Populate currencies from API data
        for (const currencyCode in rates) {
          const exchangeRate = rates[currencyCode];
          const currency = new Currency(currencyCode, currencyCode, exchangeRate); 
          this.addCurrency(currency);
        }
        
        return true; // Indicate successful update
      } else {
        throw new Error('Failed to fetch exchange rates.');
      }
    } catch (error) {
      console.error('Error updating exchange rates:', error.message);
      return false; // Indicate failure
    }
  }
}

class CurrencyConverter {
  constructor(manager, transactionHistory) {
    this.manager = manager;
    this.transactionHistory = transactionHistory;
  }

  convert(amount, sourceCurrency, targetCurrency) {
    const sourceCurrencyObj = this.manager.getCurrencies().find(currency => currency.code === sourceCurrency);
    const targetCurrencyObj = this.manager.getCurrencies().find(currency => currency.code === targetCurrency);

    if (!sourceCurrencyObj || !targetCurrencyObj) {
      console.error('Invalid source or target currency.');
      return NaN;
    }

    const sourceRate = sourceCurrencyObj.exchangeRate;
    const targetRate = targetCurrencyObj.exchangeRate;

    if (!sourceRate || !targetRate) {
      console.error('Missing exchange rate for source or target currency.');
      return NaN;
    }

    const result = (amount / sourceRate) * targetRate;
    const transaction = {
      sourceCurrency,
      targetCurrency,
      amount,
      result,
      timestamp: new Date().toLocaleString(),
    };

    this.transactionHistory.addTransaction(transaction);

    return result;
  }
}

class TransactionHistory {
  constructor() {
    this.history = [];
  }

  addTransaction(transaction) {
    this.history.push(transaction);
  }

  undoLastConversion() {
    if (this.history.length === 0) {
      console.log('No conversion to undo.');
      return;
    }

    // Get the last transaction
    const lastTransaction = this.history.pop();
  
    console.log('Undoing last conversion:', lastTransaction);

    this.updateUIDisplay();

    return lastTransaction;
  }

  updateUIDisplay() {
    console.log('Updating UI display...');
  }

  clearHistory() {
    this.history = [];
    console.log('Transaction history cleared.');
  }

  getFullHistory() {
    return this.history.slice(); 
  }
}

const currencyManager = new CurrencyManager();
const transactionHistory = new TransactionHistory();
const currencyConverter = new CurrencyConverter(currencyManager, transactionHistory);

async function populateCurrencies(apiKey) {
  const success = await currencyManager.updateExchangeRates(apiKey);
  
  if (success) {
    // Populate dropdowns with supported currencies
    const sourceCurrencyDropdown = document.getElementById('sourceCurrency');
    const targetCurrencyDropdown = document.getElementById('targetCurrency');
  
    currencyManager.getCurrencies().forEach(currency => {
      const option = document.createElement('option');
      option.value = currency.code;
      option.text = currency.name;
      sourceCurrencyDropdown.add(option.cloneNode(true));
      targetCurrencyDropdown.add(option);
    });
  } else {
    // Handle failure to fetch currencies
    console.error('Failed to fetch currencies.');
  }
}

async function convertCurrency() {
  const amount = parseFloat(document.getElementById('amount').value);
  const sourceCurrency = document.getElementById('sourceCurrency').value;
  const targetCurrency = document.getElementById('targetCurrency').value;

  if (isNaN(amount) || amount <= 0) {
    alert('Invalid amount. Please enter a positive number.');
    return;
  }

  const apiKey = 'c8b7157fe8816c5ce07b9b32';
  await populateCurrencies(apiKey);

  const result = currencyConverter.convert(amount, sourceCurrency, targetCurrency);
  document.getElementById('result').innerText = `Result: ${result.toFixed(2)}`;
}



function undoConversion() {
  // Call the undoLastConversion method from the TransactionHistory
  const undoneTransaction = transactionHistory.undoLastConversion();

  // Check if there was a conversion to undo
  if (undoneTransaction) {
    // Update the UI and history display
    updateHistoryDisplay();
    updateResultDisplay();
  } else {
    console.log('No conversion to undo.');
  }
}


function updateHistoryDisplay() {
  const historyListElement = document.getElementById('historyList');

  // Clear the existing history display
  historyListElement.innerHTML = '';

  // Retrieve the updated transaction history
  const fullHistory = transactionHistory.getFullHistory();

  // Iterate through the history and add entries to the display
  fullHistory.forEach(transaction => {
    const entry = document.createElement('li');
    entry.textContent = `${transaction.sourceCurrency} to ${transaction.targetCurrency}: ${transaction.amount} => ${transaction.result.toFixed(2)} (${transaction.timestamp})`;
    historyListElement.appendChild(entry);
  });
}


function updateResultDisplay() {
  const resultElement = document.getElementById('result');
  resultElement.innerText = 'Result: N/A'; 
}


window.onload = async function() {
  const apiKey = 'c8b7157fe8816c5ce07b9b32';
  await populateCurrencies(apiKey);
};
