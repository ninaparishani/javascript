/*Objective: The objective of this assignment is to explore and implement AJAX auto-complete functionality using JavaScript. You will create a web page that dynamically suggests and displays auto-complete results based on user input, fetched asynchronously from an external data source.

Requirements:

Select a Data Source:

Choose a data source for your auto-complete functionality. It can be a simple JSON file, a public API, or any other data source that provides information suitable for auto-complete suggestions.
Create an HTML Page:

Develop an HTML file that includes an input field where users can enter their search queries.
Create a section on the page to display auto-complete suggestions dynamically.
Implement Auto-Complete Functionality:

Write JavaScript code to implement the auto-complete functionality using AJAX.
Use the XMLHttpRequest object or the modern fetch API to asynchronously fetch data based on user input.
Implement event handlers to trigger AJAX requests when the user types in the input field.
Display Auto-Complete Suggestions:

Handle the asynchronous response from the data source.
Update the DOM dynamically to display auto-complete suggestions below the input field.
Ensure the suggestions are relevant and meaningful based on the user's input.
Enhance User Experience:

Implement features to improve the user experience, such as keyboard navigation through suggestions and highlighting the matching parts of the suggestions.
Styling (Optional):

Apply CSS styles to enhance the visual presentation of the auto-complete suggestions.
Consider using transitions or animations to create a smoother user experience.
Error Handling:

Implement error handling for scenarios like network errors or when the data source does not respond as expected.
Display meaningful error messages to users when necessary.
Documentation:

Include comments in your JavaScript code to explain key sections.
Write a brief document describing the chosen data source, the purpose of your auto-complete feature, and any challenges you faced during the implementation. */


document.addEventListener("DOMContentLoaded", function(){
    const searchInput = document.getElementById('searchInput');
    const suggestions = document.getElementById('suggestions');

    // Event listener for input changes in the search input field
    searchInput.addEventListener('input', function(){
        const userInput = searchInput.value.trim();

        // If user input is not empty, fetch suggestions
        if(userInput.length > 0){
            fetchSuggestions(userInput)
                .then(displaySuggestions)
                .catch(handleError);
        } else {
            clearSuggestions();
        }
    });

    // Event listener for clicking on a suggestion
    suggestions.addEventListener("click", function(event){
        const selectedSuggestion = event.target.textContent;
        searchInput.value = selectedSuggestion;
        clearSuggestions();
    });

    // Function to fetch suggestions asynchronously
    async function fetchSuggestions(userInput){
        const apiKey = "27f961835c09c4a90f8065895c1cad8d";
        const url = `https://ws.audioscrobbler.com/2.0/?method=artist.search&artist=${userInput}&api_key=${apiKey}&format=json`;

        const response = await fetch(url);
        if (!response.ok) {
            throw new Error("Response was not ok.");
        }
        return response.json();
    }

    function displaySuggestions(data){
        suggestions.innerHTML = "";
        if(data.results && data.results.artistmatches.artist.length > 0){
            data.results.artistmatches.artist.forEach(result => {
                const suggestionElement = document.createElement("div");
                suggestionElement.textContent = result.name;
                suggestionElement.classList.add("suggestion");
                suggestions.appendChild(suggestionElement);
            });
        } else {
            const noResults = document.createElement("div");
            noResults.textContent = "No results found";
            suggestions.appendChild(noResults);
        }
    }

    function clearSuggestions(){
        suggestions.innerHTML = "";
    }

    function handleError(error){
        console.error("Error fetching suggestions", error.message);
        suggestions.innerHTML = "An error occurred. Please try again.";
    }
});
